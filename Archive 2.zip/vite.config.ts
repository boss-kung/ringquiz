import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/ringquiz/',
  plugins: [react()],
  server: {
    port: 5173,
  },
});
